from django.urls import path
from authApp import views

#template urls

app_name = 'authApp'

urlpatterns = [
    path('register/',views.register, name = 'register'),
    path('user_login',views.user_login,name='user_login')
]
