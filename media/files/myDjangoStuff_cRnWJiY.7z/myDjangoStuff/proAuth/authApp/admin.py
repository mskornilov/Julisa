from django.contrib import admin
from authApp.models import UserProfileInfo

# Register your models here.

admin.site.register(UserProfileInfo)
