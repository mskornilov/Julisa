from django.shortcuts import render


# Create your views here.

def index(request):
    myDict = {
    "insert_content": "hello im from firstApp"
    }
    return render(request, 'firstAPP/index.html', context = myDict)
