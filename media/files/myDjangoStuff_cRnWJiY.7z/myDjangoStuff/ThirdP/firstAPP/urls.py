from django.urls import path
from firstAPP import views

urlpatterns = [
    path(r'',views.index, name='index')
]
