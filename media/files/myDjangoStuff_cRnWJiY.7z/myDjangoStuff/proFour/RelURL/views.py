from django.shortcuts import render

# Create your views here.

def index(request):
    return render(request, 'RelURL/index.html')

def other(request):
    return render(request, 'RelURL/other.html')

def RelURL(request):
    return render(request, 'RelURL/RelURL.html')
