from django.urls import path
from RelURL import views

#Template taging
app_name = 'RelURL'

urlpatterns = [
    path('relative', views.RelURL, name = 'relative'),
    path('other', views.other, name = 'other'),
]
