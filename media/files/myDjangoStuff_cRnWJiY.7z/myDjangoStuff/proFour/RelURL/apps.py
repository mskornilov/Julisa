from django.apps import AppConfig


class RelurlConfig(AppConfig):
    name = 'RelURL'
