import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'proTwo.settings')

import django
django.setup()



from faker import Faker
import random
from secondApp.models import Person

fakegen = Faker()

def populate(N=5):
    for entry in range(N):

        fakeFN = fakegen.name()
        fakeFName = fakeFN.split()[0]
        fakeLN = fakegen.name()
        fakeLName = fakeLN.split()[-1]
        fakeEmail = fakegen.safe_email()


        pers = Person.objects.get_or_create(firstName = fakeFName, lastName = fakeLName, email = fakeEmail)[0]


if __name__ == '__main__':
    print('population starts')
    populate(20)
    print('population complete')
