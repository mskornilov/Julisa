from django.shortcuts import render
from django.http import HttpResponse
from secondApp.models import Person
from secondApp import forms
# Create your views here.


def index(request):
    return HttpResponse('<h1> Welcome to the index page </h1> \n <h2> To access user information go to /users page </h2>' )

def users(request):
    pers = Person.objects.order_by('firstName')
    persDict = {'person': pers}
    return render(request, 'secondApp/users.html', context = persDict)
    # return HttpResponse("<em>My second app </em>")

def help(request):
    myHelp = {'insertHere': "Here's the text, that was imported from views.py file. Behold!"}
    return render(request, 'secondApp/Help.html', context = myHelp)

def Person_form(request):
    form = forms.PersonForm()
    if request.method == 'POST':
        form = forms.PersonForm(request.POST)

        if form.is_valid():
            print('saving data')
            form.save()

    return render(request, 'secondApp/form.html',{'form': form})
