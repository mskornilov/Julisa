from django.urls import path
from secondApp import views

urlpatterns = [
    path(r'',views.index, name = 'index'),
    path(r'form',views.Person_form,name='form'),
    path(r'users', views.users, name = 'users'),
    path(r'help', views.help, name = 'help')
]





# from django.conf.urls import url
# from firstApp import views
#
# urlpatterns = [
#     url(r'',views.index,name='index'),
