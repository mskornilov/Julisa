from django.forms import ModelForm
from secondApp.models import Person

class PersonForm(ModelForm):
    class Meta:
        model = Person
        fields = ['firstName','lastName','email']
