from django.contrib import admin
from secondApp.models import Person
# Register your models here.

admin.site.register(Person)
