from django.shortcuts import render
from django.http import HttpResponse
from firstApp.models import AccessRecord, Webpage, Topic
# Create your views here.

def index(request):
    webpagesList = AccessRecord.objects.order_by('date')
    dateDict = {'accessRecord': webpagesList}

    myDict = {'insertMe': 'Now im coming from firstApp/index.html'}
    return render(request, 'firstApp/index.html', context = dateDict)
