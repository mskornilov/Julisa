import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'firstProject.settings')

import django
django.setup()


# fake pop script
import random
from firstApp.models import AccessRecord, Webpage, Topic
from faker import Faker

fakegen = Faker()
topics = ['Search', 'Social', 'Marketplace', 'News', 'Games']

def add_topic():
    t = Topic.objects.get_or_create(topName = random.choice(topics))[0]
    t.save()
    return t

def populate(N=5):
    for entry in range(N):

        #get the topic for the entry
        top = add_topic()

        #Create the fake data for that entry
        fakeURL = fakegen.url()
        fakeDate = fakegen.date()
        fakeName = fakegen.name()

        #Create the new webpage entry
        webpg = Webpage.objects.get_or_create(topic = top, url = fakeURL, name = fakeName)[0]

        #Create a fake access record for that Webpage
        accRec = AccessRecord.objects.get_or_create(name = webpg, date = fakeDate)[0]

if __name__ == '__main__':
    print('population script')
    populate(20)
    print('population complete')
